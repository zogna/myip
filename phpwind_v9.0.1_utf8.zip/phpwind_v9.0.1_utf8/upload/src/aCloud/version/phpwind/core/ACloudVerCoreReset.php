<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
class ACloudVerCoreReset {
	
	public function execute() {
	
	}

}