<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );

class ACloudVerCommonSearch extends ACloudVerCommonBase {
	
	public function getHotwords() {
	
	}
}