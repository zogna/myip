<?php
/**
 * @author Shi Long <long.shi@alibaba-inc.com> 2010-11-2
 * @link http://www.phpwind.com
 * @copyright Copyright &copy; 2003-2010 phpwind.com
 * @license
 */
return array(
	'config_rewrite' => array('URL伪静态', 'rewrite/rewrite/*', '', '', 'config', 'config_seo'),
	'config_domain' => array('二级域名', 'rewrite/domain/*', '', '', 'config', 'config_rewrite'),
);