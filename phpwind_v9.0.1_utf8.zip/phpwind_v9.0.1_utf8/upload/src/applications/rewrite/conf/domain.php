<?php
/**
 * @author Shi Long <long.shi@alibaba-inc.com>
 * @link http://www.phpwind.com
 * @copyright Copyright &copy; 2003-2010 phpwind.com
 * @license
 */
/*
 * 别名 => array(名称, 'm/c/a', array(m/c/a))
 * */
return array(
	'default' => array('默认', ''),
	'forum' => array('论坛', 'bbs/index/run'),
	'space' => array('空间', 'space/index/run'),
	'special' => array('门户', 'special/index/run'), 
	'tag' => array('话题', '')
);