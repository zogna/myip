<?php
/**
 * @author xiaoxia.xu <x_824@sina.com> 2010-11-2
 * @link http://www.phpwind.com
 * @copyright Copyright ©2003-2010 phpwind.com
 * @license
 */
return array(
	'appcenter_task' => array('任务中心', 'task/manage,taskConditionBbs,taskConditionCntv,taskConditionMember,taskReward/*', '', '', 'appcenter'),
);