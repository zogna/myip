<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'appcenter' => array('应用中心', array()), 
	'appcenter_vote' => array('投票管理', 'vote/manage/*', '', '', 'appcenter'), 
);