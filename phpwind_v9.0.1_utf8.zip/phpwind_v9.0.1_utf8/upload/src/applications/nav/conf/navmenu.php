<?php 
defined('WEKIT_VERSION') or exit(403);

return array(
	'config_nav' => array('导航设置', 'nav/nav/*', '', '', 'config', 'config_verifycode'),
);