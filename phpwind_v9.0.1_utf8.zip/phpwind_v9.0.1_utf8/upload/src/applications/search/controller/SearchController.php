<?php

class SearchController extends PwBaseController {
	
	public function run() {
	
	}

}