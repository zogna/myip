<?php 
defined('WEKIT_VERSION') or exit(403);

return array(
	'config_verifycode' => array('验证码设置', 'verify/verify/*', '', '', 'config', 'config_register'),
);