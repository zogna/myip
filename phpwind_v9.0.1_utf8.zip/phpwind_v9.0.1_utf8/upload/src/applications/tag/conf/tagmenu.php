<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'contents' => array('内容', array()),
	'contents_tag' => array('话题管理', 'tag/manage/*', '', '', 'contents'), 
);