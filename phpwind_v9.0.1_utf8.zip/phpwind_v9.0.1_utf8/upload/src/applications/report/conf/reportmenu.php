<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'contents_report' => array('举报管理', 'report/manage/*', '', '', 'contents'), 
);