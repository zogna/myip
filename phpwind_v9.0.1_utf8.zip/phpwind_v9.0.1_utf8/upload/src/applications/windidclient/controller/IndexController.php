<?php
Wind::import('LIB:base.PwBaseController');

class IndexController extends PwBaseController {
	
	public function run() {
		exit;
	}
	

}
?>
