<?php
Wind::import('WIND:viewer.AbstractWindTemplateCompiler');
/**
 * Enter description here ...
 *
 * @author Qiong Wu <papa0924@gmail.com> 2011-11-21
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.windframework.com
 * @version $Id: PwTemplateCompilerLang.php 3215 2011-12-14 06:41:22Z yishuo $
 * @package wekit
 */
class PwTemplateCompilerLang extends AbstractWindTemplateCompiler {

	/* (non-PHPdoc)
	 * @see AbstractWindTemplateCompiler::compile()
	 */
	public function compile($key, $content) {
		// TODO Auto-generated method stub
	

	}

}

?>